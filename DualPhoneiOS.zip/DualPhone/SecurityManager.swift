import SwiftUI
import LocalAuthentication
import CryptoKit

class SecurityManager: ObservableObject {
    static let shared = SecurityManager()

    @Published var failedAttempts = 0
    @Published var isLocked = false
    private let maxAttempts = 5
    private let lockoutDuration: TimeInterval = 30

    private var realPin: String {
        get { KeychainHelper.load(key: "real_pin") ?? "2580" }
        set { KeychainHelper.save(key: "real_pin", value: newValue) }
    }

    private var decoyPin: String {
        get { KeychainHelper.load(key: "decoy_pin") ?? "1234" }
        set { KeychainHelper.save(key: "decoy_pin", value: newValue) }
    }

    func validate(pin: String) -> PhoneMode? {
        if isLocked { return nil }
        if pin == realPin { failedAttempts = 0; return .real }
        else if pin == decoyPin { failedAttempts = 0; return .decoy }
        else {
            failedAttempts += 1
            if failedAttempts >= maxAttempts { lockDevice() }
            return nil
        }
    }

    private func lockDevice() {
        isLocked = true
        DispatchQueue.main.asyncAfter(deadline: .now() + lockoutDuration) { [weak self] in
            self?.isLocked = false
            self?.failedAttempts = 0
        }
    }

    func authenticateBiometric() async -> Bool {
        let context = LAContext()
        var error: NSError?
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            do {
                return try await context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Unlock your secure phone")
            } catch { return false }
        }
        return false
    }
}

enum PhoneMode: Identifiable {
    case real, decoy
    var id: Int { self == .real ? 0 : 1 }
}

class KeychainHelper {
    static func save(key: String, value: String) {
        let data = value.data(using: .utf8)!
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        SecItemDelete(query as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }

    static func load(key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: AnyObject?
        SecItemCopyMatching(query as CFDictionary, &result)
        guard let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}
