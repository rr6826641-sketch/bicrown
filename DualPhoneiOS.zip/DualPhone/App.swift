import SwiftUI

@main
struct DualPhoneApp: App {
    var body: some Scene {
        WindowGroup {
            LockScreenView()
        }
    }
}
