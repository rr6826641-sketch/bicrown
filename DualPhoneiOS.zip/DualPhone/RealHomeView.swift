import SwiftUI

struct RealHomeView: View {
    @Environment(\.dismiss) private var dismiss

    let apps = [
        ("envelope.fill", "Mail"),
        ("person.2.fill", "Contacts"),
        ("bubble.left.fill", "Messages"),
        ("calendar", "Calendar"),
        ("play.rectangle.fill", "Media"),
        ("folder.fill", "Files"),
        ("gearshape.fill", "Settings"),
        ("shield.fill", "Vault")
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Welcome back").font(.caption).foregroundColor(.secondary)
                            Text("Alex").font(.title2.weight(.medium))
                        }
                        Spacer()
                        Image(systemName: "person.circle.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            WidgetCard(title: "Balance", value: "$24,580", subtitle: "+2.4% today", color: .green)
                            WidgetCard(title: "Messages", value: "3 unread", subtitle: "2 from Sarah", color: .blue)
                        }
                        .padding(.horizontal)
                    }

                    Text("Apps").font(.headline).padding(.horizontal)

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 72))], spacing: 20) {
                        ForEach(apps, id: \ .1) { app in
                            AppIcon(icon: app.0, name: app.1)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.top)
            }
            .navigationTitle("Home")
            .navigationBarHidden(true)
        }
    }
}

struct WidgetCard: View {
    let title: String, value: String, subtitle: String, color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.caption).foregroundColor(.secondary)
            Text(value).font(.title3.weight(.medium))
            Text(subtitle).font(.caption).foregroundColor(color)
        }
        .frame(width: 160, alignment: .leading)
        .padding(16)
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct AppIcon: View {
    let icon: String, name: String
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundColor(.primary)
                .frame(width: 52, height: 52)
                .background(Color(.systemGray6))
                .cornerRadius(12)
            Text(name).font(.caption).foregroundColor(.secondary)
        }
    }
}
