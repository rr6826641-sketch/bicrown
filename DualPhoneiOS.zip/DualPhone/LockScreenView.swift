import SwiftUI

struct LockScreenView: View {
    @State private var pin = ""
    @State private var showError = false
    @State private var shakeOffset: CGFloat = 0
    @State private var selectedMode: PhoneMode?
    @StateObject private var security = SecurityManager.shared

    private let pinLength = 4

    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer().frame(height: 80)

                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 48))
                    .foregroundColor(.primary)
                    .padding(.bottom, 24)

                Text("Enter PIN")
                    .font(.title2.weight(.medium))
                    .foregroundColor(.primary)

                HStack(spacing: 16) {
                    ForEach(0..<pinLength, id: \ .self) { index in
                        Circle()
                            .fill(index < pin.count ? Color.primary : Color.clear)
                            .frame(width: 16, height: 16)
                            .overlay(Circle().stroke(Color.primary.opacity(0.2), lineWidth: 2))
                    }
                }
                .padding(.top, 24)
                .offset(x: shakeOffset)

                if security.isLocked {
                    Text("Too many attempts. Locked for 30s")
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.top, 12)
                } else if showError {
                    Text("Incorrect PIN")
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.top, 12)
                }

                Spacer()

                VStack(spacing: 16) {
                    ForEach([[1,2,3],[4,5,6],[7,8,9]], id: \ .self) { row in
                        HStack(spacing: 24) {
                            ForEach(row, id: \ .self) { digit in
                                KeypadButton(digit: digit) { pressDigit(digit) }
                            }
                        }
                    }
                    HStack(spacing: 24) {
                        Spacer().frame(width: 72)
                        KeypadButton(digit: 0) { pressDigit(0) }
                        Button(action: backspace) {
                            Image(systemName: "delete.backward")
                                .font(.title2)
                                .foregroundColor(.primary)
                                .frame(width: 72, height: 72)
                        }
                    }
                }
                .padding(.bottom, 40)
                .disabled(security.isLocked)
                .opacity(security.isLocked ? 0.3 : 1)

                Button(action: authenticateBiometric) {
                    Image(systemName: "touchid")
                        .font(.title2)
                        .foregroundColor(.primary)
                        .frame(width: 56, height: 56)
                }
                .padding(.bottom, 20)

                Text("Try 2580 (real) or 1234 (decoy)")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .padding(.bottom, 16)
            }
        }
        .fullScreenCover(item: $selectedMode) { mode in
            switch mode {
            case .real: RealHomeView()
            case .decoy: DecoyHomeView()
            }
        }
    }

    private func pressDigit(_ digit: Int) {
        guard pin.count < pinLength else { return }
        pin += String(digit)
        showError = false
        if pin.count == pinLength {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { validatePin() }
        }
    }

    private func backspace() {
        guard !pin.isEmpty else { return }
        pin.removeLast()
        showError = false
    }

    private func validatePin() {
        if let mode = security.validate(pin: pin) {
            selectedMode = mode
        } else {
            showError = true
            shakePin()
            pin = ""
        }
    }

    private func shakePin() {
        withAnimation(.easeInOut(duration: 0.05)) { shakeOffset = 20 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            withAnimation(.easeInOut(duration: 0.05)) { shakeOffset = -20 }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation(.easeInOut(duration: 0.05)) { shakeOffset = 20 }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            withAnimation(.easeInOut(duration: 0.05)) { shakeOffset = 0 }
        }
    }

    private func authenticateBiometric() {
        Task {
            let success = await security.authenticateBiometric()
            if success {
                await MainActor.run { selectedMode = .real }
            }
        }
    }
}

struct KeypadButton: View {
    let digit: Int
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text("\(digit)")
                .font(.title2.weight(.medium))
                .foregroundColor(.primary)
                .frame(width: 72, height: 72)
                .background(Circle().fill(Color(.systemGray6)))
        }
        .buttonStyle(PlainButtonStyle())
    }
}
