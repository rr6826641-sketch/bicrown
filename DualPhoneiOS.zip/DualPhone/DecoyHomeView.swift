import SwiftUI

struct DecoyHomeView: View {
    let apps = [
        ("play.rectangle.fill", "YouTube"),
        ("globe", "Browser"),
        ("camera.fill", "Camera"),
        ("music.note", "Music"),
        ("bubble.left.fill", "Messages"),
        ("map.fill", "Maps"),
        ("note.text", "Notes"),
        ("gearshape.fill", "Settings")
    ]

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Hello").font(.caption).foregroundColor(.secondary)
                            Text("Guest").font(.title2.weight(.medium))
                        }
                        Spacer()
                        Image(systemName: "person.circle.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.secondary)
                    }
                    .padding(.horizontal)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            WidgetCard(title: "Weather", value: "24°C", subtitle: "Sunny, clear", color: .orange)
                            WidgetCard(title: "Steps", value: "3,421", subtitle: "Goal: 10,000", color: .blue)
                        }
                        .padding(.horizontal)
                    }

                    Text("Apps").font(.headline).padding(.horizontal)

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 72))], spacing: 20) {
                        ForEach(apps, id: \ .1) { app in
                            AppIcon(icon: app.0, name: app.1)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.top)
            }
            .navigationTitle("Home")
            .navigationBarHidden(true)
        }
    }
}
